package AuroraSkinCare;

//Represent a specific type of treatment :- MoleRemoval Treatment
public class MoleRemoval extends Treatment {
	
	// Constructs an MoleRemovalTreatment object with preset values.
	public MoleRemoval() {
        super(3, "Mole Removal", 3850.00);
    }

}
