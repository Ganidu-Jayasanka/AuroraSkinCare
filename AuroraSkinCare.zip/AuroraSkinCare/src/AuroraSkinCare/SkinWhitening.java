package AuroraSkinCare;


//Represent a specific type of treatment :- SkinWhitening Treatment
public class SkinWhitening extends Treatment {
   
	// Constructs an SkinWhiteningTreatment object with preset values.
    
	public SkinWhitening() {
        super(2, "Skin Whitening", 7650.00);
    }

}
